/* ============================================================
   SYNONTECH — main.js
   Nav scroll shadow, mobile menu, active nav links, form UX
   ============================================================ */

(function () {
  'use strict';

  // --- NAV SCROLL SHADOW ---
  const nav = document.querySelector('.nav');
  if (nav) {
    window.addEventListener('scroll', () => {
      nav.classList.toggle('scrolled', window.scrollY > 8);
    }, { passive: true });
  }

  // --- MOBILE MENU TOGGLE ---
  const toggle = document.querySelector('.nav__toggle');
  const mobileMenu = document.querySelector('.nav__mobile');

  if (toggle && mobileMenu) {
    toggle.addEventListener('click', () => {
      const isOpen = mobileMenu.classList.toggle('open');
      toggle.setAttribute('aria-expanded', isOpen);
    });

    // Close on outside click
    document.addEventListener('click', (e) => {
      if (!nav.contains(e.target)) {
        mobileMenu.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // --- ACTIVE NAV LINK (by current page) ---
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav__links a, .nav__mobile a').forEach(link => {
    const linkPath = link.getAttribute('href').split('/').pop();
    if (linkPath === currentPath) {
      link.classList.add('active');
    }
  });

  // --- CONTACT FORM (basic client-side UX) ---
  const form = document.getElementById('contactForm');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();

      const name    = form.querySelector('#name').value.trim();
      const email   = form.querySelector('#email').value.trim();
      const message = form.querySelector('#message').value.trim();

      if (!name || !email || !message) {
        showFormMessage('Please fill in your name, email, and message.', 'error');
        return;
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        showFormMessage('Please enter a valid email address.', 'error');
        return;
      }

      // Simulate submit (replace with actual endpoint when ready)
      const btn = form.querySelector('.contact-form__submit');
      btn.textContent = 'Sending...';
      btn.disabled = true;

      setTimeout(() => {
        showFormMessage("Message sent. We'll get back to you soon.", 'success');
        form.reset();
        btn.textContent = 'Send Message';
        btn.disabled = false;
      }, 1200);
    });
  }

  function showFormMessage(text, type) {
    let msg = document.querySelector('.form-feedback');
    if (!msg) {
      msg = document.createElement('p');
      msg.className = 'form-feedback';
      const form = document.getElementById('contactForm');
      form.appendChild(msg);
    }
    msg.textContent = text;
    msg.style.cssText = `
      font-size: 13px;
      margin-top: 4px;
      padding: 10px 14px;
      border-radius: 6px;
      background: ${type === 'success' ? '#ECFDF5' : '#FEF2F2'};
      color: ${type === 'success' ? '#059669' : '#DC2626'};
      border: 1px solid ${type === 'success' ? '#D1FAE5' : '#FEE2E2'};
    `;
    setTimeout(() => msg.remove(), 5000);
  }

})();
